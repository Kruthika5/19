package com.niit.ecart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shopingcart.dao.UserDAO;
import com.niit.shopingcart.model.UserDetails;



@Controller

public class UserController {

   @Autowired
	UserDAO userDAO;
   
   @RequestMapping("/")
  	public String getLanding()
  	{
  		System.out.println("Index page called...");
  		return "index";
  	}
  
	
	@RequestMapping("/home")
	public String getHome()
	{
		return "home";
	}
	@RequestMapping("/index")
	public String getIndex()
	{
		return "index";
    }
	@RequestMapping("/login")
	public String getLogin()
	{
		return "loginUser";
	}
	@RequestMapping("/contact")
	public String getContact()
	{
		return "contact";
	}
	@RequestMapping("/about")
	public String getAboutus()
	{
		return "about";
	}
	
	@RequestMapping("/signup")
	public String getsignup()
	{
		return "signup";	
	}
    
    @RequestMapping("/isValidUser")
	public ModelAndView isValidUser(@RequestParam(value = "name") String name,
			@RequestParam(value = "password") String password) {
		System.out.println("in controller");

		String message;
		ModelAndView mv ;
		if (userDAO.isValidUser(name, password,true)) 
		{
			message = "Valid credentials";
			 mv = new ModelAndView("adminHome");
			   //mv.addObject("userID", userID);
		} else {
			message = "Invalid credentials";
			 mv = new ModelAndView("login");
		}

		mv.addObject("message", message);
		mv.addObject("name", name);
		return mv;
	}
	
	
	@RequestMapping("/register")
	public ModelAndView registerUser(@ModelAttribute UserDetails userDetails) {
		userDAO.saveOrUpdate(userDetails);
	  return new ModelAndView("/adminHome");
	 }


}
